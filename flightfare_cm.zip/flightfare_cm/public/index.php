<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>FlightFare-CM - Paiement Mobile Money (Demo)</title>
</head>
<body>
  <h1>FlightFare-CM - Paiement Mobile Money (demo)</h1>
  <form id="payForm">
    <label>Booking ID: <input type="number" id="booking_id" value="1"></label><br>
    <label>Provider:
      <select id="provider">
        <option value="MTN">MTN MoMo</option>
        <option value="ORANGE">Orange Money</option>
      </select>
    </label><br>
    <label>MSISDN (format 2376xxxxxxxx): <input type="text" id="msisdn" value="237690000000"></label><br>
    <button type="submit">Initier paiement (demo)</button>
  </form>
  <pre id="output"></pre>
  <script src="js/payment.js"></script>
</body>
</html>
