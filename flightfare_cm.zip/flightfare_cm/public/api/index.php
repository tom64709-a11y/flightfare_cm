<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");

$uri = trim($_SERVER['REQUEST_URI'], '/');
$uri = explode('/', $uri);

if ($uri[0] !== 'flightfare_cm' || $uri[1] !== 'public' || $uri[2] !== 'api') {
    echo json_encode(["error" => "API endpoint not found"]);
    exit;
}

// Exemple: /flightfare_cm/public/api/payments/simulate
$controller = $uri[3] ?? null;
$action = $uri[4] ?? null;

switch ($controller) {

    case "payments":
        require "../../app/controllers/ApiPaymentsController.php";
        $ctrl = new ApiPaymentsController();

        if ($action === "simulate") {
            $ctrl->simulate();
        }
        break;

    case "reservations":
        require "../../app/controllers/ApiReservationsController.php";
        $ctrl = new ApiReservationsController();

        if ($action === "add") {
            $ctrl->add();
        }
        break;

    default:
        echo json_encode(["error" => "Unknown API route"]);
}
<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");

$uri = explode('/', trim($_SERVER['REQUEST_URI'], '/'));
$method = $_SERVER['REQUEST_METHOD'];

// Exemple d’URI : /flightfare_cm/public/api/reservations/add
if ($uri[0] !== "flightfare_cm" || $uri[1] !== "public" || $uri[2] !== "api") {
    echo json_encode(["error" => "API route not found"]);
    exit;
}

$controller = $uri[3] ?? null;
$action     = $uri[4] ?? null;

switch ($controller) {

    case "payments":
        require "../../app/controllers/ApiPaymentsController.php";
        $ctrl = new ApiPaymentsController();

        if ($method === "POST" && $action === "simulate") {
            $ctrl->simulate();
        }

        if ($method === "GET" && $action === "status") {
            $ctrl->status();
        }

        break;


    case "reservations":
        require "../../app/controllers/ApiReservationsController.php";
        $ctrl = new ApiReservationsController();

        if ($method === "POST" && $action === "add") {
            $ctrl->add();
        }

        if ($method === "GET" && $action === "list") {
            $ctrl->list();
        }

        break;


    default:
        echo json_encode(["error" => "Unknown API controller"]);
}
