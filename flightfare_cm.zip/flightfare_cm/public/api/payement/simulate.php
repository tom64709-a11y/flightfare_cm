<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");

$response = [
    "status" => "success",
    "transaction_id" => "API-SIM-" . rand(100000,999999),
    "amount" => $_POST['amount'] ?? 0,
    "currency" => "XAF",
    "message" => "Paiement API simulé"
];

echo json_encode($response);
