document.getElementById('payForm').addEventListener('submit', async function(e){
  e.preventDefault();
  const booking_id = document.getElementById('booking_id').value;
  const provider = document.getElementById('provider').value;
  const msisdn = document.getElementById('msisdn').value;

  const resp = await fetch(`/flightfare_cm/public/payments/initiate/${booking_id}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ provider, msisdn })
  });
  const data = await resp.json();
  document.getElementById('output').textContent = JSON.stringify(data, null, 2);
});
