<?php
/**
 * FlightFare-CM Full Deployment Script
 * Usage: php setup_full.php
 */

echo "=== FlightFare-CM Full Deployment ===\n\n";

// 1️⃣ Vérification PHP et Composer
exec('php -v', $phpVersion);
echo "PHP Version: " . implode("\n", $phpVersion) . "\n";

exec('composer --version', $composerVersion, $retCode);
if ($retCode !== 0) {
    die("Composer introuvable. Installe Composer pour continuer.\n");
}
echo "Composer Version: " . implode("\n", $composerVersion) . "\n\n";

// 2️⃣ Installer CodeIgniter 4 si absent
if(!is_dir('app')) {
    echo "Installation CodeIgniter 4...\n";
    exec('composer create-project codeigniter4/appstarter .', $ciOutput, $ret);
    echo implode("\n", $ciOutput) . "\n";
}

// 3️⃣ Création fichier .env
$envPath = __DIR__.'/.env';
if (!file_exists($envPath)) copy(__DIR__.'/env', $envPath);

$envContent = file_get_contents($envPath);
$envContent = preg_replace("/database.default.hostname=.*/", "database.default.hostname=localhost", $envContent);
$envContent = preg_replace("/database.default.database=.*/", "database.default.database=flightfare_cm", $envContent);
$envContent = preg_replace("/database.default.username=.*/", "database.default.username=root", $envContent);
$envContent = preg_replace("/database.default.password=.*/", "database.default.password=", $envContent);
$envContent = preg_replace("/database.default.DBDriver=.*/", "database.default.DBDriver=MySQLi", $envContent);
$envContent .= "\nMTN_CLIENT_ID=ton_client_id_mtn";
$envContent .= "\nMTN_CLIENT_SECRET=ton_client_secret_mtn";
$envContent .= "\nMTN_SUBSCRIPTION_KEY=ta_subscription_key_mtn";
$envContent .= "\nMTN_TOKEN_URL=https://sandbox.momodeveloper.mtn.com/collection/token/";
$envContent .= "\nMTN_COLLECTION_URL=https://sandbox.momodeveloper.mtn.com/collection/v1_0/requesttopay";
$envContent .= "\nORANGE_CLIENT_ID=ton_client_id_orange";
$envContent .= "\nORANGE_CLIENT_SECRET=ton_client_secret_orange";
$envContent .= "\nORANGE_TOKEN_URL=https://sandbox.orange.com/oauth/v2/token";
$envContent .= "\nORANGE_COLLECTION_URL=https://sandbox.orange.com/api/payment";
file_put_contents($envPath, $envContent);
echo ".env configuré avec DB et clés MTN/Orange\n\n";

// 4️⃣ Création base + tables
echo "Création base et tables...\n";

$mysqli = new mysqli("localhost", "root", "", "");
if($mysqli->connect_error) die("Erreur DB: ".$mysqli->connect_error);

$mysqli->query("CREATE DATABASE IF NOT EXISTS flightfare_cm CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;");
$mysqli->select_db("flightfare_cm");

// Table users
$mysqli->query("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);");

// Table bookings
$mysqli->query("CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    flight_from VARCHAR(50),
    flight_to VARCHAR(50),
    departure_date DATE,
    return_date DATE,
    seats INT,
    amount_fcfa INT,
    status ENUM('pending','paid','cancelled') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);");

// Table payments
$mysqli->query("CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT,
    provider ENUM('MTN','ORANGE'),
    amount_fcfa INT,
    transaction_ref VARCHAR(50),
    status ENUM('initiated','completed','failed') DEFAULT 'initiated',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
);");

// 5️⃣ Données de test
$mysqli->query("INSERT INTO users (full_name, phone, email) VALUES ('Jean Dupont','237699112233','jean@example.com');");
$mysqli->query("INSERT INTO bookings (user_id, flight_from, flight_to, departure_date, return_date, seats, amount_fcfa) 
VALUES (1,'Douala','Yaoundé','2025-12-10','2025-12-15',1,50000);");

echo "Base, tables et données de test créées ✅\n";

// 6️⃣ Précharger vues & CSS
$dirs = ['app/Views/layout','app/Views/bookings','app/Views/dashboard','public/assets/css','public/assets/js'];
foreach($dirs as $d) if(!is_dir($d)) mkdir($d, 0777, true);

// Copier CSS
$css = <<<CSS
body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color:#f2f9f2; }
h2 { color:#007f3f; }
.table th { background-color:#ffd700; color:#000; }
.status-paid { color: green; font-weight:bold; }
.status-pending { color: orange; font-weight:bold; }
.status-cancelled { color: red; font-weight:bold; }
.btn-pay { background-color:#ff0000; color:#fff; }
.btn-save { background-color:#ff0000; color:#fff; }
.navbar { margin-bottom:20px; }
CSS;
file_put_contents('public/assets/css/style.css', $css);

echo "\n✅ Frontend minimal complet prêt (vues + CSS)\n";
echo "Accède à http://localhost/flightfare_cm/public/dashboard pour voir ton Dashboard.\n";
echo "Tu peux maintenant créer des réservations, initier des paiements MTN/Orange et suivre le tout.\n";
