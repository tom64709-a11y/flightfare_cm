<?php
namespace App\Database;

use PDO;
use Exception;

class InitDatabase
{
    private $host = 'localhost';
    private $db   = 'flightfare_cm';
    private $user = 'root';
    private $pass = ''; // mot de passe XAMPP si défini
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct()
    {
        try {
            // Connexion sans base (pour créer la DB si nécessaire)
            $this->pdo = new PDO("mysql:host={$this->host}", $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            echo "Connexion MySQL réussie.\n";

            // Création de la base si inexistante
            $this->pdo->exec("CREATE DATABASE IF NOT EXISTS {$this->db} CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;");
            echo "Base de données '{$this->db}' OK.\n";

            // Reconnexion sur la base
            $this->pdo = new PDO("mysql:host={$this->host};dbname={$this->db}", $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $this->createTables();
            $this->insertSampleData();

        } catch (Exception $e) {
            die("Erreur : " . $e->getMessage());
        }
    }

    private function createTables()
    {
        $tables = [

            "CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                full_name VARCHAR(150) NOT NULL,
                email VARCHAR(100) NOT NULL UNIQUE,
                phone VARCHAR(20) NOT NULL,
                password VARCHAR(255) NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );",

            "CREATE TABLE IF NOT EXISTS bookings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                flight_from VARCHAR(50),
                flight_to VARCHAR(50),
                departure_date DATE,
                return_date DATE,
                seats INT DEFAULT 1,
                amount_fcfa DECIMAL(12,2) NOT NULL,
                status ENUM('pending','paid','cancelled') DEFAULT 'pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            );",

            "CREATE TABLE IF NOT EXISTS payments (
                id INT AUTO_INCREMENT PRIMARY KEY,
                booking_id INT NOT NULL,
                provider ENUM('MTN','ORANGE') NOT NULL,
                amount_fcfa DECIMAL(12,2) NOT NULL,
                transaction_ref VARCHAR(50) UNIQUE,
                status ENUM('initiated','completed','failed') DEFAULT 'initiated',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
            );"
        ];

        foreach ($tables as $sql) {
            $this->pdo->exec($sql);
        }

        echo "Tables créées avec succès.\n";
    }

    private function insertSampleData()
    {
        // Exemple utilisateur
        $passwordHash = password_hash('password123', PASSWORD_DEFAULT);
        $this->pdo->exec("INSERT INTO users (full_name,email,phone,password) VALUES
            ('Jean Dupont','jean.dupont@example.com','237699112233','$passwordHash')
        ;");

        // Exemple réservation
        $this->pdo->exec("INSERT INTO bookings (user_id,flight_from,flight_to,departure_date,return_date,seats,amount_fcfa,status) VALUES
            (1,'Douala','Yaoundé','2025-12-01','2025-12-05',1,50000,'pending')
        ;");

        echo "Données d'exemple insérées.\n";
    }
}

// Exécution du script
new InitDatabase();