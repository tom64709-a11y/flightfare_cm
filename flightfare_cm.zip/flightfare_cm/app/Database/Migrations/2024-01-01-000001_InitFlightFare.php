<?php
namespace App\Database\Migrations;
use CodeIgniter\Database\Migration;

class InitFlightFare extends Migration
{
    public function up()
    {
        // USERS
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'auto_increment' => true],
            'full_name'   => ['type' => 'VARCHAR', 'constraint' => 120],
            'email'       => ['type' => 'VARCHAR', 'constraint' => 120],
            'password'    => ['type' => 'VARCHAR', 'constraint' => 255],
            'phone'       => ['type' => 'VARCHAR', 'constraint' => 20],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
            'updated_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('users', true);

        // FLIGHTS
        $this->forge->addField([
            'id'           => ['type' => 'INT', 'auto_increment' => true],
            'origin'       => ['type' => 'VARCHAR', 'constraint' => 120],
            'destination'  => ['type' => 'VARCHAR', 'constraint' => 120],
            'airline'      => ['type' => 'VARCHAR', 'constraint' => 120],
            'price_fcfa'   => ['type' => 'INT'],
            'departure_at' => ['type' => 'DATETIME'],
            'arrival_at'   => ['type' => 'DATETIME'],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('flights', true);

        // BOOKINGS
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'auto_increment' => true],
            'user_id'     => ['type' => 'INT'],
            'flight_id'   => ['type' => 'INT'],
            'amount_fcfa' => ['type' => 'INT'],
            'status'      => ['type' => 'ENUM', 'constraint' => ['pending','paid','cancelled'], 'default' => 'pending'],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('user_id', 'users', 'id');
        $this->forge->addForeignKey('flight_id', 'flights', 'id');
        $this->forge->createTable('bookings', true);

        // PAYMENTS
        $this->forge->addField([
            'id'              => ['type' => 'INT', 'auto_increment' => true],
            'booking_id'      => ['type' => 'INT'],
            'provider'        => ['type' => 'VARCHAR', 'constraint' => 20],
            'amount_fcfa'     => ['type' => 'INT'],
            'transaction_ref' => ['type' => 'VARCHAR', 'constraint' => 100],
            'status'          => ['type'=>'ENUM','constraint'=>['initiated','completed','failed'],'default'=>'initiated'],
            'created_at'      => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('booking_id','bookings','id');
        $this->forge->createTable('payments', true);
    }

    public function down()
    {
        $this->forge->dropTable('payments', true);
        $this->forge->dropTable('bookings', true);
        $this->forge->dropTable('flights', true);
        $this->forge->dropTable('users', true);
    }
}
