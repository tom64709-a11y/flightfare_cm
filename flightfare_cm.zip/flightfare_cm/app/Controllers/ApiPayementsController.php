<?php

class ApiPaymentsController {

    // POST – simulate un paiement
    public function simulate() {
        $data = json_decode(file_get_contents("php://input"), true);

        if (!isset($data['amount'])) {
            echo json_encode([
                "status" => "error",
                "message" => "amount field is required"
            ]);
            return;
        }

        echo json_encode([
            "status" => "success",
            "transaction_id" => "SIM-" . rand(100000, 999999),
            "amount" => $data['amount'],
            "message" => "Payment simulation OK"
        ]);
    }

    // GET – renvoie un statut fictif
    public function status() {
        echo json_encode([
            "service" => "payments",
            "status" => "online",
            "timestamp" => time()
        ]);
    }
}
