<?php
namespace App\Controllers;

use App\Models\BookingModel;
use App\Models\UserModel;
use CodeIgniter\Controller;

class Bookings extends Controller
{
    public function index()
    {
        $bookingModel = new BookingModel();
        $data['bookings'] = $bookingModel->join('users', 'users.id = bookings.user_id')
                                         ->select('bookings.*, users.full_name, users.phone')
                                         ->orderBy('bookings.created_at', 'DESC')
                                         ->findAll();

        return view('bookings/index', $data);
    }

    public function create()
    {
        return view('bookings/create');
    }

    public function store()
    {
        $bookingModel = new BookingModel();

        $bookingModel->insert([
            'user_id' => 1, // Jean Dupont pour l’instant
            'flight_from' => $this->request->getPost('flight_from'),
            'flight_to' => $this->request->getPost('flight_to'),
            'departure_date' => $this->request->getPost('departure_date'),
            'return_date' => $this->request->getPost('return_date'),
            'seats' => $this->request->getPost('seats'),
            'amount_fcfa' => $this->request->getPost('amount_fcfa'),
            'status' => 'pending'
        ]);

        return redirect()->to('/bookings');
    }
}