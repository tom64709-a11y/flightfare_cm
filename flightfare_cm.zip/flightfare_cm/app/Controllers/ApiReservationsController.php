<?php

class ApiReservationsController {

    public function add() {
        $json = file_get_contents("php://input");
        $data = json_decode($json, true);

        if (!isset($data['client']) || !isset($data['destination'])) {
            echo json_encode([
                "status" => "error",
                "message" => "client and destination are required"
            ]);
            return;
        }

        echo json_encode([
            "status" => "success",
            "reservation_id" => rand(1000, 9999),
            "client" => $data['client'],
            "destination" => $data['destination']
        ]);
    }
}
<?php

class ApiReservationsController {

    // POST – ajouter une réservation
    public function add() {
        $data = json_decode(file_get_contents("php://input"), true);

        if (!isset($data['client']) || !isset($data['destination'])) {
            echo json_encode([
                "status" => "error",
                "message" => "client and destination required"
            ]);
            return;
        }

        echo json_encode([
            "status" => "success",
            "reservation_id" => rand(1000, 9999),
            "client" => $data['client'],
            "destination" => $data['destination']
        ]);
    }

    // GET – liste des réservations fictives
    public function list() {
        echo json_encode([
            "status" => "success",
            "reservations" => [
                ["id" => 1, "client" => "Jean", "destination" => "Paris"],
                ["id" => 2, "client" => "Marie", "destination" => "Dubaï"]
            ]
        ]);
    }
}
    // GET – liste des réservations fictives
    public function list() {
        echo json_encode([
            "status" => "success",
            "reservations" => [
                ["id" => 1, "client" => "Alice", "destination" => "New York"],
                ["id" => 2, "client" => "Bob", "destination" => "Tokyo"]
            ]
        ]);
    }
}