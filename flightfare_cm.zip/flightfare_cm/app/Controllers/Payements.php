<?php
namespace App\Controllers;

use App\Models\PaymentModel;
use App\Models\BookingModel;
use App\Models\UserModel;
use CodeIgniter\API\ResponseTrait;

class Payments extends BaseController
{
    use ResponseTrait;

    /**
     * Initier un paiement (simulé localement)
     */
    public function initiate($booking_id)
    {
        helper(['text']);

        $bookingModel = new BookingModel();
        $booking = $bookingModel->find($booking_id);

        if (!$booking) {
            return $this->failNotFound("Réservation introuvable");
        }

        // Validation des données envoyées
        $rules = [
            'provider' => 'required|in_list[MTN,ORANGE]',
            'msisdn'   => 'required|min_length[11]|max_length[15]'
        ];

        if (!$this->validate($rules)) {
            return $this->failValidationErrors($this->validator->getErrors());
        }

        $provider = $this->request->getVar('provider');
        $msisdn   = $this->request->getVar('msisdn');
        $ref      = 'SIM-' . strtoupper(random_string('alpha', 4)) . '-' . time();

        // Création du paiement dans la base
        $paymentModel = new PaymentModel();
        $paymentModel->insert([
            'booking_id'      => $booking_id,
            'provider'        => $provider,
            'amount_fcfa'     => $booking['amount_fcfa'],
            'transaction_ref' => $ref,
            'status'          => 'completed', // paiement simulé
            'created_at'      => date('Y-m-d H:i:s')
        ]);

        // Mise à jour du statut de la réservation
        $bookingModel->update($booking_id, ['status' => 'paid']);

        log_message('info', "Paiement simulé: $ref, provider=$provider, booking_id=$booking_id");

        return $this->respond([
            'status'  => 'completed',
            'transaction_ref' => $ref,
            'provider' => $provider,
            'amount' => $booking['amount_fcfa'],
            'message' => 'Paiement simulé en local'
        ]);
    }

    /**
     * Affiche le formulaire de simulation de paiement
     */
    public function simulateForm()
    {
        $bookingModel = new BookingModel();
        $userModel    = new UserModel();
        $bookingsRaw  = $bookingModel->findAll();

        $bookings = [];
        foreach ($bookingsRaw as $b) {
            $user = $userModel->find($b['user_id']);
            $b['full_name'] = $user ? $user['full_name'] : 'Inconnu';
            $bookings[] = $b;
        }

        return view('dashboard/simulate_payment', ['bookings' => $bookings]);
    }

    /**
     * Simuler un paiement depuis le formulaire web
     */
    public function simulate()
    {
        $booking_id = $this->request->getPost('booking_id');
        $provider   = strtoupper($this->request->getPost('provider'));

        $bookingModel = new BookingModel();
        $paymentModel = new PaymentModel();

        $booking = $bookingModel->find($booking_id);
        if (!$booking) {
            return redirect()->back()->with('error', 'Réservation introuvable');
        }

        $ref    = 'SIM-' . strtoupper(bin2hex(random_bytes(2))) . '-' . time();
        $amount = $booking['amount_fcfa'];

        $paymentModel->insert([
            'booking_id'      => $booking_id,
            'provider'        => $provider,
            'amount_fcfa'     => $amount,
            'transaction_ref' => $ref,
            'status'          => 'completed',
            'created_at'      => date('Y-m-d H:i:s')
        ]);

        $bookingModel->update($booking_id, ['status' => 'paid']);

        return redirect()->to('/payments/simulate')
                         ->with('success', "Paiement simulé: $provider, $amount FCFA, Ref: $ref");
    }

    /**
     * Webhook local (optionnel pour tests)
     */
    public function webhook()
    {
        $ref    = $this->request->getVar('transaction_ref');
        $status = $this->request->getVar('status');

        $paymentModel = new PaymentModel();
        $bookingModel = new BookingModel();

        $payment = $paymentModel->where('transaction_ref', $ref)->first();
        if (!$payment) {
            return $this->failNotFound("Transaction inconnue");
        }

        $paymentModel->update($payment['id'], ['status' => $status]);

        if ($status === 'completed') {
            $bookingModel->update($payment['booking_id'], ['status' => 'paid']);
        }

        log_message('info', "Webhook simulé reçu pour $ref => $status");

        return $this->respond(['ack' => true]);
    }
}
