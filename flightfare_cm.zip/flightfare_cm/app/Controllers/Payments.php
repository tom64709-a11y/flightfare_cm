<?php
namespace App\Controllers;
use App\Models\PaymentModel;
use App\Models\BookingModel;
use CodeIgniter\API\ResponseTrait;

class Payments extends BaseController
{
    use ResponseTrait;

    public function initiate($booking_id = null)
    {
        $bookingModel = new BookingModel();
        $booking = $bookingModel->find($booking_id);
        if (!$booking) return $this->failNotFound("Réservation introuvable");

        $provider = $this->request->getVar('provider') ?? 'MTN';
        $msisdn = $this->request->getVar('msisdn'); // format: 2376xxxxxxxx

        $paymentModel = new PaymentModel();
        $ref = 'CM-PAY-'.time().'-'.rand(1000,9999);

        $paymentModel->insert([
            'booking_id'      => $booking_id,
            'provider'        => $provider,
            'amount_fcfa'     => $booking['amount_fcfa'],
            'transaction_ref' => $ref,
            'status'          => 'initiated',
            'created_at'      => date('Y-m-d H:i:s')
        ]);

        // Return response for frontend — actual call to provider to be implemented server-side
        return $this->respond([
            'message' => 'Paiement initié (simulé). Remplis .env pour activer fournisseur réel.',
            'provider' => $provider,
            'amount' => $booking['amount_fcfa'] . ' FCFA',
            'transaction_ref' => $ref
        ]);
    }

    public function webhook()
    {
        // Provider will POST transaction_ref and status
        $ref = $this->request->getVar('transaction_ref');
        $status = $this->request->getVar('status'); // completed / failed

        $paymentModel = new PaymentModel();
        $payment = $paymentModel->where('transaction_ref', $ref)->first();
        if (!$payment) return $this->failNotFound("Transaction inconnue");

        $paymentModel->update($payment['id'], ['status' => $status]);
        if ($status === 'completed') {
            (new BookingModel())->update($payment['booking_id'], ['status' => 'paid']);
        }

        return $this->respond(['ack' => true]);
    }
}
public function simulateForm()
{
    $bookingModel = new \App\Models\BookingModel();
    $userModel = new \App\Models\UserModel();
    $bookingsRaw = $bookingModel->findAll();

    $bookings = [];
    foreach($bookingsRaw as $b){
        $user = $userModel->find($b['user_id']);
        $b['full_name'] = $user ? $user['full_name'] : 'Inconnu';
        $bookings[] = $b;
    }

    return view('dashboard/simulate_payment', ['bookings' => $bookings]);
}

public function simulate()
{
    $booking_id = $this->request->getPost('booking_id');
    $provider = strtoupper($this->request->getPost('provider'));

    $bookingModel = new \App\Models\BookingModel();
    $paymentModel = new \App\Models\PaymentModel();

    $booking = $bookingModel->find($booking_id);
    if(!$booking){
        return redirect()->back()->with('error','Réservation introuvable');
    }

    $ref = 'SIM-' . strtoupper(bin2hex(random_bytes(2))) . '-' . time();
    $amount = $booking['amount_fcfa'];

    $paymentModel->insert([
        'booking_id' => $booking_id,
        'provider' => $provider,
        'amount_fcfa' => $amount,
        'transaction_ref' => $ref,
        'status' => 'completed',
        'created_at' => date('Y-m-d H:i:s')
    ]);

    $bookingModel->update($booking_id, ['status'=>'paid']);

    return redirect()->to('/payments/simulate')->with('success', "Paiement simulé: $provider, $amount FCFA, Ref: $ref");
}

  