<?php
namespace App\Controllers;

use App\Models\BookingModel;
use App\Models\PaymentModel;
use CodeIgniter\Controller;

class Dashboard extends Controller
{
    public function index()
    {
        $bookingModel = new BookingModel();
        $paymentModel = new PaymentModel();

        $data['total_bookings'] = $bookingModel->countAll();
        $data['total_paid']     = $paymentModel->where('status','completed')->countAllResults();
        $data['total_pending']  = $paymentModel->where('status','initiated')->countAllResults();
        $data['total_revenue']  = $paymentModel->selectSum('amount_fcfa')->where('status','completed')->first()['amount_fcfa'] ?? 0;

        return view('dashboard/index', $data);
    }
}
