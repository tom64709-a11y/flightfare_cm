<?php
namespace App\Controllers;

use App\Models\BookingModel;
use CodeIgniter\Controller;

class TestBooking extends Controller
{
    public function index()
    {
        $bookingModel = new BookingModel();

        $bookingModel->insert([
            'user_id' => 1,
            'flight_from' => 'Douala',
            'flight_to' => 'Yaoundé',
            'departure_date' => '2025-12-10',
            'return_date' => '2025-12-15',
            'seats' => 1,
            'amount_fcfa' => 50000,
            'status' => 'pending'
        ]);

        echo "Réservation créée pour Jean Dupont ✅";
    }
}