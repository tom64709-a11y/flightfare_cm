<?php

use CodeIgniter\Router\RouteCollection;
$routes->post('payments/initiate/(:num)', 'Payments::initiate/$1');
$routes->post('payments/webhook', 'Payments::webhook');
$routes->get('/', 'Dashboard::index');
$routes->get('/dashboard', 'Dashboard::index');
$routes->post('/payments/initiate/(:num)', 'Payments::initiate/$1');
$routes->get('/', 'Dashboard::index');
$routes->get('/dashboard', 'Dashboard::index');
$routes->get('/payments/simulate', 'Payments::simulateForm');
$routes->post('/payments/simulate', 'Payments::simulate');
$routes->post('/payments/initiate/(:num)', 'Payments::initiate/$1');
$routes->get('/payments/simulate', 'Payments::simulateForm');
$routes->post('/payments/simulate', 'Payments::simulate');
$routes->post('/payments/webhook', 'Payments::webhook');

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
