<nav class="navbar navbar-expand-lg navbar-dark" style="background-color:#007f3f;">
    <div class="container">
        <a class="navbar-brand" href="/dashboard">FlightFare-CM</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="/bookings">Réservations</a></li>
                <li class="nav-item"><a class="nav-link" href="/dashboard">Dashboard</a></li>
            </ul>
        </div>
    </div>
</nav>
<nav class="navbar" style="background-color:#007f3f; padding:10px;">
    <a href="/dashboard"><img src="<?= base_url('assets/img/logo.png') ?>" height="40"> FlightFare-CM</a>
</nav>
