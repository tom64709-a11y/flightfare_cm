<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>FlightFare-CM</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
    <link rel="icon" href="<?= base_url('favicon.ico') ?>" type="image/x-icon" />
</head>
<body>
    <?php if (isset($navbar)) echo $navbar; ?>
    <div class="container">
        <?= $this->renderSection('content') ?>
    </div>
</body>
</html>

    Modifie tes vues (ex: app/Views/dashboard/index.php) :

<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<h2>Dashboard FlightFare-CM</h2>
<table class="table">
    <tr>
        <th>ID Réservation</th>
        <th>Utilisateur</th>
        <th>Montant (FCFA)</th>
        <th>Status</th>
    </tr>
    <?php foreach($bookings as $b): ?>
    <tr>
        <td><?= $b['id'] ?></td>
        <td><?= $b['user_id'] ?></td>
        <td><?= $b['amount_fcfa'] ?></td>
        <td class="status-<?= $b['status'] ?>"><?= ucfirst($b['status']) ?></td>
    </tr>
    <?php endforeach; ?>
</table>
<?= $this->endSection() ?>