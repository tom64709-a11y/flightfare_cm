div class="text-center py-3">
    <img src="<?= base_url('assets/img/logo.png') ?>" height="60" alt="FlightFare-CM">
</div>