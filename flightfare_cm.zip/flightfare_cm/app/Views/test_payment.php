<h2>Test Paiement FlightFare-CM</h2>
<form method="post" action="<?= base_url('payments/initiate/2') ?>">
    <label>Opérateur:</label>
    <select name="provider">
        <option value="MTN">MTN Mobile Money</option>
        <option value="ORANGE">Orange Money</option>
    </select><br><br>
    
    <label>Numéro MSISDN:</label>
    <input type="text" name="msisdn" value="237699112233" required><br><br>
    
    <button type="submit">Payer 50 000 FCFA</button>
</form>