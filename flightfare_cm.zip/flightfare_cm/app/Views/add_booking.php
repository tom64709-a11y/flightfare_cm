<h2>Ajouter une réservation pour Jean</h2>
<form method="post" action="<?= base_url('testbooking/save') ?>">
    Départ: <input type="text" name="flight_from" value="Douala"><br>
    Arrivée: <input type="text" name="flight_to" value="Yaoundé"><br>
    Date départ: <input type="date" name="departure_date" value="2025-12-10"><br>
    Date retour: <input type="date" name="return_date" value="2025-12-15"><br>
    Nombre de sièges: <input type="number" name="seats" value="1"><br>
    Montant (FCFA): <input type="number" name="amount_fcfa" value="50000"><br>
    <button type="submit">Ajouter réservation</button>
</form>
