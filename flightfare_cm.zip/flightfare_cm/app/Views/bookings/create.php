<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Nouvelle Réservation | FlightFare-CM</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #e6f2e6; color: #333; }
        .navbar { background-color: #007f3f; color: #fff; }
        .btn-save { background-color: #ff0000; color: #fff; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg p-3 mb-4">
    <a class="navbar-brand text-white" href="/bookings">FlightFare-CM</a>
</nav>

<div class="container">
    <h2>Nouvelle Réservation</h2>
    <form method="post" action="<?= base_url('bookings/store') ?>" class="mt-3">
        <div class="mb-3">
            <label>Départ</label>
            <input type="text" name="flight_from" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Destination</label>
            <input type="text" name="flight_to" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Date de départ</label>
            <input type="date" name="departure_date" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Date de retour</label>
            <input type="date" name="return_date" class="form-control">
        </div>
        <div class="mb-3">
            <label>Nombre de sièges</label>
            <input type="number" name="seats" class="form-control" value="1" required>
        </div>
        <div class="mb-3">
            <label>Montant (FCFA)</label>
            <input type="number" name="amount_fcfa" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-save">Enregistrer</button>
    </form>
</div>
</body>
</html>