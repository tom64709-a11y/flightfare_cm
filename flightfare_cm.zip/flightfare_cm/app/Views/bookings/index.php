<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>FlightFare-CM | Réservations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #e6f2e6; color: #333; }
        .navbar { background-color: #007f3f; color: #fff; }
        .btn-pay { background-color: #ff0000; color: #fff; }
        .table th { background-color: #ffd700; }
        .status-paid { color: green; font-weight: bold; }
        .status-pending { color: orange; font-weight: bold; }
        .status-cancelled { color: red; font-weight: bold; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg p-3 mb-4">
    <a class="navbar-brand text-white" href="#">FlightFare-CM</a>
    <div class="ms-auto">
        <a href="/bookings/create" class="btn btn-light">Nouvelle Réservation</a>
    </div>
</nav>

<div class="container">
    <h2>Liste des Réservations</h2>
    <table class="table table-striped mt-3">
        <thead>
            <tr>
                <th>Client</th>
                <th>Vol</th>
                <th>Départ</th>
                <th>Retour</th>
                <th>Sièges</th>
                <th>Montant (FCFA)</th>
                <th>Statut</th>
                <th>Paiement</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($bookings as $b): ?>
            <tr>
                <td><?= esc($b['full_name']) ?></td>
                <td><?= esc($b['flight_from']) ?> → <?= esc($b['flight_to']) ?></td>
                <td><?= esc($b['departure_date']) ?></td>
                <td><?= esc($b['return_date']) ?></td>
                <td><?= esc($b['seats']) ?></td>
                <td><?= number_format($b['amount_fcfa'],0,","," ") ?></td>
                <td class="status-<?= $b['status'] ?>"><?= ucfirst($b['status']) ?></td>
                <td>
                    <?php if($b['status'] == 'pending'): ?>
                    <form method="post" action="<?= base_url('payments/initiate/'.$b['id']) ?>">
                        <select name="provider" class="form-select mb-1" required>
                            <option value="MTN">MTN Mobile Money</option>
                            <option value="ORANGE">Orange Money</option>
                        </select>
                        <input type="text" name="msisdn" class="form-control mb-1" placeholder="237699112233" required>
                        <button type="submit" class="btn btn-pay btn-sm">Payer</button>
                    </form>
                    <?php else: ?>
                        ✅ Paiement <?= ucfirst($b['status']) ?>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>