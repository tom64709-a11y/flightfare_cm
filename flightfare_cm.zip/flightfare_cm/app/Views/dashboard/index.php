<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>FlightFare-CM | Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link href="<?= base_url('assets/css/style.css') ?>" rel="stylesheet">
</head>
<body>
<?php include('layout/navbar.php'); ?>

<div class="container mt-4">
    <h2>Tableau de Bord FlightFare-CM</h2>
    <div class="row mt-3">
        <div class="col-md-3">
            <div class="card text-white bg-success mb-3">
                <div class="card-body">
                    <h5>Total Réservations</h5>
                    <p class="card-text"><?= $total_bookings ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-primary mb-3">
                <div class="card-body">
                    <h5>Réservations Payées</h5>
                    <p class="card-text"><?= $total_paid ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-warning mb-3">
                <div class="card-body">
                    <h5>En attente</h5>
                    <p class="card-text"><?= $total_pending ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-danger mb-3">
                <div class="card-body">
                    <h5>Revenu Total (FCFA)</h5>
                    <p class="card-text"><?= number_format($total_revenue,0,","," ") ?></p>
                </div>
            </div>
        </div>
    </div>

    <canvas id="paymentsChart" height="100"></canvas>
</div>

<script>
const ctx = document.getElementById('paymentsChart').getContext('2d');
const chart = new Chart(ctx, {
    type: 'pie',
    data: {
        labels: ['Payées', 'En attente', 'Annulées'],
        datasets: [{
            label: 'Paiements',
            data: [<?= $total_paid ?>, <?= $total_pending ?>, <?= $total_bookings - $total_paid - $total_pending ?>],
            backgroundColor: ['#28a745','#ffc107','#dc3545']
        }]
    },
});
</script>
</body>
</html><link rel="icon" type="image/png" href="<?= base_url('assets/img/logo.png') ?>" />
<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<h2>Dashboard FlightFare-CM</h2>
<table class="table">
    <tr>
        <th>ID Réservation</th>
        <th>Utilisateur</th>
        <th>De → Vers</th>
        <th>Départ / Retour</th>
        <th>Montant (FCFA)</th>
        <th>Status</th>
        <th>Actions</th>
    </tr>
    <?php foreach($bookings as $b): ?>
    <tr>
        <td><?= $b['id'] ?></td>
        <td><?= $b['full_name'] ?></td>
        <td><?= $b['flight_from'] ?> → <?= $b['flight_to'] ?></td>
        <td><?= $b['departure_date'] ?> / <?= $b['return_date'] ?></td>
        <td><?= $b['amount_fcfa'] ?></td>
        <td class="status-<?= $b['status'] ?>"><?= ucfirst($b['status']) ?></td>
        <td>
            <?php if($b['status'] === 'pending'): ?>
                <form action="/payments/initiate/<?= $b['id'] ?>" method="POST" style="display:inline;">
                    <input type="hidden" name="provider" value="MTN">
                    <input type="hidden" name="msisdn" value="237699112233">
                    <button class="btn btn-pay">Payer MTN</button>
                </form>
                <form action="/payments/initiate/<?= $b['id'] ?>" method="POST" style="display:inline;">
                    <input type="hidden" name="provider" value="ORANGE">
                    <button class="btn btn-pay">Payer Orange</button>
                </form>
            <?php else: ?>
                <button class="btn btn-disabled" disabled>Payé</button>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
<?= $this->endSection() ?><table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Utilisateur</th>
            <th>Vol</th>
            <th>Montant (FCFA)</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($bookings as $b): ?>
        <tr>
            <td><?= $b['id'] ?></td>
            <td><?= $b['full_name'] ?></td>
            <td><?= $b['flight_from'] ?> → <?= $b['flight_to'] ?></td>
            <td><?= $b['amount_fcfa'] ?></td>
            <td><?= ucfirst($b['status']) ?></td>
            <td>
                <?php if($b['status'] !== 'paid'): ?>
                    <form style="display:inline" method="POST" action="/payments/initiate/<?= $b['id'] ?>">
                        <input type="hidden" name="provider" value="MTN">
                        <input type="hidden" name="msisdn" value="237600000000">
                        <button class="btn btn-mtn">Payer MTN</button>
                    </form>

                    <form style="display:inline" method="POST" action="/payments/initiate/<?= $b['id'] ?>">
                        <input type="hidden" name="provider" value="ORANGE">
                        <input type="hidden" name="msisdn" value="237600000000">
                        <button class="btn btn-orange">Payer Orange</button>
                    </form>

                    <!-- Bouton simulation -->
                    <form style="display:inline" method="POST" action="/payments/simulate">
                        <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">
                        <input type="hidden" name="provider" value="MTN">
                        <button class="btn btn-simulate">Simuler paiement</button>
                    </form>
                <?php else: ?>
                    <span class="text-success">Payé</span>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>