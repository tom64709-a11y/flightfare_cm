<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<h2>Simuler un Paiement</h2>

<?php if(session()->getFlashdata('success')): ?>
<div class="alert alert-success">
    <?= session()->getFlashdata('success') ?>
</div>
<?php endif; ?>

<form action="/payments/simulate" method="POST">
    <div class="form-group">
        <label>Réservation</label>
        <select name="booking_id" class="form-control" required>
            <option value="">-- Choisir une réservation --</option>
            <?php foreach($bookings as $b): ?>
            <option value="<?= $b['id'] ?>">
                #<?= $b['id'] ?> - <?= $b['full_name'] ?> (<?= $b['amount_fcfa'] ?> FCFA) - <?= ucfirst($b['status']) ?>
            </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label>Provider</label>
        <select name="provider" class="form-control" required>
            <option value="MTN">MTN</option>
            <option value="ORANGE">ORANGE</option>
        </select>
    </div>

    <button type="submit" class="btn btn-pay mt-2">Simuler le paiement</button>
</form>
<?= $this->endSection() ?>