<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<h2>Nouvelle Réservation</h2>

<?php if(isset($validation)): ?>
<div class="alert alert-danger">
    <?= $validation->listErrors() ?>
</div>
<?php endif; ?>

<form action="/bookings/store" method="POST">
    <div class="form-group">
        <label>Nom complet de l’utilisateur</label>
        <input type="text" name="full_name" class="form-control" required>
    </div>

    <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" class="form-control" required>
    </div>

    <div class="form-group">
        <label>Vol de départ</label>
        <input type="text" name="flight_from" class="form-control" required>
    </div>

    <div class="form-group">
        <label>Vol de destination</label>
        <input type="text" name="flight_to" class="form-control" required>
    </div>

    <div class="form-group">
        <label>Date de départ</label>
        <input type="date" name="departure_date" class="form-control" required>
    </div>

    <div class="form-group">
        <label>Date de retour</label>
        <input type="date" name="return_date" class="form-control">
    </div>

    <div class="form-group">
        <label>Montant (FCFA)</label>
        <input type="number" name="amount_fcfa" class="form-control" required>
    </div>

    <button type="submit" class="btn btn-pay mt-2">Créer la réservation</button>
</form>
<?= $this->endSection() ?>
