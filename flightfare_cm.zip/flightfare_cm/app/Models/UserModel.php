<?php
namespace App\Models;
use CodeIgniter\Model;

class UserModel extends Model {
    protected $table = 'users';
    protected $allowedFields = ['full_name','email','password','phone','created_at','updated_at'];
    protected $returnType = 'array';
}
