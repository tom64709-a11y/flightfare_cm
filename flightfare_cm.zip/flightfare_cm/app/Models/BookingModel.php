<?php
namespace App\Models;

use CodeIgniter\Model;

class BookingModel extends Model
{
    protected $table = 'bookings';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'user_id',
        'flight_from',
        'flight_to',
        'amount_fcfa',
        'status', // pending / paid
        'created_at',
        'updated_at'
    ];

    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
}
require 'app/Models/BookingModel.php';

$bookingModel = new \App\Models\BookingModel();
$bookingModel->insert([
    'user_id' => 1,  // ID de Jean
    'flight_from' => 'Douala',
    'flight_to' => 'Yaoundé',
    'amount_fcfa' => 15000,
    'status' => 'pending',
    'created_at' => date('Y-m-d H:i:s')
]);
echo "Réservation pour Jean créée ✔";