<?php
namespace App\Models;

use CodeIgniter\Model;

class FlightModel extends Model {
    protected $table = 'flights';
    protected $allowedFields = ['origin','destination','airline','price_fcfa','departure_at','arrival_at'];
}
