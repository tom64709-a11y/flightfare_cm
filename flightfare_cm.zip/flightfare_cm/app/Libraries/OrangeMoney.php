<?php
namespace App\Libraries;

class OrangeMoney
{
    private $client_id;
    private $client_secret;
    private $token_url;
    private $collection_url;

    public function __construct()
    {
        $this->client_id      = getenv('ORANGE_CLIENT_ID');
        $this->client_secret  = getenv('ORANGE_CLIENT_SECRET');
        $this->token_url      = getenv('ORANGE_TOKEN_URL');
        $this->collection_url = getenv('ORANGE_COLLECTION_URL');
    }

    public function getToken()
    {
        $headers = ["Authorization: Basic " . base64_encode("{$this->client_id}:{$this->client_secret}")];
        $ch = curl_init($this->token_url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => "grant_type=client_credentials"
        ]);

        $res = json_decode(curl_exec($ch), true);
        return $res['access_token'] ?? null;
    }

    public function webPayment($ref, $amount)
    {
        $token = $this->getToken();
        if (!$token) return false;

        $headers = [
            "Authorization: Bearer $token",
            "Content-Type: application/json"
        ];

        $payload = json_encode([
            "order_id" => $ref,
            "amount" => $amount,
            "currency" => "XAF"
        ]);

        $ch = curl_init($this->collection_url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => $payload
        ]);

        return curl_exec($ch);
    }
}