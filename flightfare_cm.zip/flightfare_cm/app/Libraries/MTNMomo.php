<?php
namespace App\Libraries;
class MTNMomo {
    private $client_id;
    private $client_secret;
    private $subscription_key;
    private $token_url;
    private $collection_url;
    public function __construct() {
        $this->client_id = getenv('MTN_CLIENT_ID');
        $this->client_secret = getenv('MTN_CLIENT_SECRET');
        $this->subscription_key = getenv('MTN_SUBSCRIPTION_KEY');
        $this->token_url = getenv('MTN_TOKEN_URL');
        $this->collection_url = getenv('MTN_COLLECTION_URL');
    }
    public function getToken() {
        $headers = [
            "Authorization: Basic " . base64_encode("{$this->client_id}:{$this->client_secret}"),
            "Ocp-Apim-Subscription-Key: {$this->subscription_key}"
        ];
        $ch = curl_init($this->token_url);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => $headers, CURLOPT_POSTFIELDS => "grant_type=client_credentials"]);
        $res = json_decode(curl_exec($ch), true);
        return $res['access_token'] ?? null;
    }
    public function requestToPay($ref, $amount, $msisdn) {
        $token = $this->getToken();
        if (!$token) return false;
        $headers = ["Authorization: Bearer $token", "X-Reference-Id: $ref", "Ocp-Apim-Subscription-Key: {$this->subscription_key}", "Content-Type: application/json"];
        $payload = json_encode(["amount" => $amount, "currency" => "XAF", "externalId" => $ref, "payer" => ["partyIdType" => "MSISDN", "partyId" => $msisdn], "payerMessage" => "Paiement FlightFare-CM", "payeeNote" => "Achat billet"]);
        $ch = curl_init($this->collection_url);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => $headers, CURLOPT_POSTFIELDS => $payload]);
        return curl_exec($ch);
    }
}