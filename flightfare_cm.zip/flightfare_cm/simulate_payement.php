<?php
// simulate_payment.php
// Script pour simuler un paiement (MTN / Orange) sur une réservation

use App\Models\BookingModel;
use App\Models\PaymentModel;
use CodeIgniter\I18n\Time;

require_once __DIR__ . '/app/Config/Paths.php';
require_once __DIR__ . '/vendor/autoload.php';

$paths = new Config\Paths();
$app = new \CodeIgniter\CodeIgniter($paths);

echo "=== Simulation de paiement FlightFare-CM ===\n";

// Demande ID réservation
echo "Entrez l'ID de la réservation: ";
$handle = fopen("php://stdin","r");
$booking_id = trim(fgets($handle));

$bookingModel = new BookingModel();
$booking = $bookingModel->find($booking_id);

if(!$booking){
    echo "Réservation introuvable.\n";
    exit;
}

// Choix du provider
echo "Choisir le provider (MTN/ORANGE): ";
$provider = strtoupper(trim(fgets($handle)));
if(!in_array($provider, ['MTN','ORANGE'])){
    echo "Provider invalide.\n";
    exit;
}

// Génération d'une référence
$ref = 'SIM-' . strtoupper(bin2hex(random_bytes(2))) . '-' . time();
$amount = $booking['amount_fcfa'];

// Création paiement dans DB
$paymentModel = new PaymentModel();
$paymentModel->insert([
    'booking_id' => $booking_id,
    'provider' => $provider,
    'amount_fcfa' => $amount,
    'transaction_ref' => $ref,
    'status' => 'initiated',
    'created_at' => date('Y-m-d H:i:s')
]);

// Simuler le paiement terminé
$paymentModel->update($paymentModel->getInsertID(), ['status' => 'completed']);
$bookingModel->update($booking_id, ['status' => 'paid']);

echo "Paiement simulé avec succès !\n";
echo "Réservation ID: $booking_id\n";
echo "Provider: $provider\n";
echo "Montant: $amount FCFA\n";
echo "Transaction Ref: $ref\n";
echo "Status: completed\n";

