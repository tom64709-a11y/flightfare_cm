# FlightFare-CM (Minimal CodeIgniter-style bundle)

Dépôt minimal prêt à déposer dans XAMPP `htdocs/flightfare_cm`.
Ce bundle contient :
- migrations (CodeIgniter style)
- models (User/Flight/Booking/Payment)
- controller Payments (initiate + webhook)
- routes addition
- simple frontend (public/index.html + public/js/payment.js)
- .env.example with placeholders pour MTN/Orange

## Installation rapide (Windows + XAMPP)
1. Dépose le dossier `flightfare_cm` dans `C:\xampp\htdocs\`.
2. Démarre Apache et MySQL depuis le panneau XAMPP.
3. Ouvre phpMyAdmin et crée la base `flightfare_cm` (utf8mb4).
4. Ouvre un terminal: `cd C:\xampp\htdocs\flightfare_cm`
5. Si tu as CodeIgniter 4 installé via Composer, exécute : `php spark migrate`
   (les migrations sont fournies dans app/Database/Migrations)
6. Configure `app/Config/Database.php` si nécessaire et mets les credentials MySQL.
7. Remplis `.env.example` et renomme en `.env`, ajoute les credentials MTN/ORANGE.
8. Accède à l'URL: `http://localhost/flightfare_cm/public/` pour tester la page de paiement.

## Note sur Mobile Money (MTN / Orange)
- Les classes d'intégration contiennent des placeholders. Obtiens les credentials auprès
  des portails développeurs MTN MoMo & Orange Money (sandbox d'abord).
- Remplace les valeurs dans `.env` et suis la documentation opérateur pour les URLs.

## Contenu du zip
- app/Controllers/Payments.php
- app/Models/*.php
- app/Config/Database.php (exemple)
- app/Database/Migrations/2024-01-01-000001_InitFlightFare.php
- app/Config/Routes.php (snippet)
- public/index.html
- public/js/payment.js
- .env.example
- README.md (ce fichier)

Si tu veux, je peux maintenant :
- Générer une archive ZIP téléchargeable (déjà faite ici)
- Ajouter un script d'installation automatique (PowerShell / Bash)
- Générer un contrôleur plus complet avec validation et logs
