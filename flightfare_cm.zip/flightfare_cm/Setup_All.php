<?php
/**
 * FlightFare-CM One Click Setup
 * Usage: php setup_all.php
 */

echo "=== FlightFare-CM One Click Setup ===\n\n";

// 1️⃣ Vérification PHP et Composer
exec('php -v', $phpVersion);
echo "PHP Version: " . implode("\n", $phpVersion) . "\n";

exec('composer --version', $composerVersion, $retCode);
if ($retCode !== 0) {
    die("Composer introuvable. Installe Composer pour continuer.\n");
}
echo "Composer Version: " . implode("\n", $composerVersion) . "\n\n";

// 2️⃣ Installation dépendances CodeIgniter 4
echo "Installation des dépendances via Composer...\n";
exec('composer install', $composerOutput, $retCode);
echo implode("\n", $composerOutput) . "\n\n";

// 3️⃣ Création fichier .env
$envPath = __DIR__ . '/.env';
if (!file_exists($envPath)) {
    copy(__DIR__ . '/env', $envPath);
    echo ".env créé à partir du modèle\n";
}

// Mise à jour variables DB & clés MTN/Orange
$envContent = file_get_contents($envPath);
$envContent = preg_replace("/database.default.hostname=.*/", "database.default.hostname=localhost", $envContent);
$envContent = preg_replace("/database.default.database=.*/", "database.default.database=flightfare_cm", $envContent);
$envContent = preg_replace("/database.default.username=.*/", "database.default.username=root", $envContent);
$envContent = preg_replace("/database.default.password=.*/", "database.default.password=", $envContent);
$envContent = preg_replace("/database.default.DBDriver=.*/", "database.default.DBDriver=MySQLi", $envContent);
$envContent .= "\nMTN_CLIENT_ID=ton_client_id_mtn";
$envContent .= "\nMTN_CLIENT_SECRET=ton_client_secret_mtn";
$envContent .= "\nMTN_SUBSCRIPTION_KEY=ta_subscription_key_mtn";
$envContent .= "\nMTN_TOKEN_URL=https://sandbox.momodeveloper.mtn.com/collection/token/";
$envContent .= "\nMTN_COLLECTION_URL=https://sandbox.momodeveloper.mtn.com/collection/v1_0/requesttopay";
$envContent .= "\nORANGE_CLIENT_ID=ton_client_id_orange";
$envContent .= "\nORANGE_CLIENT_SECRET=ton_client_secret_orange";
$envContent .= "\nORANGE_TOKEN_URL=https://sandbox.orange.com/oauth/v2/token";
$envContent .= "\nORANGE_COLLECTION_URL=https://sandbox.orange.com/api/payment";
file_put_contents($envPath, $envContent);
echo ".env configuré avec la DB et clés MTN/Orange\n\n";

// 4️⃣ Création base + tables + données d’exemple
echo "Création de la base de données et des tables...\n";
require_once __DIR__ . '/app/Controllers/Setup.php';
$setup = new \App\Controllers\Setup();
$setup->index(); // Exécute l’installation DB + données

echo "\n=== Installation complète réussie ! ===\n";
echo "Tu peux maintenant lancer l'application sur XAMPP.\n";
echo "Accède à http://localhost/flightfare_cm/public\n";